//
//  NoConnectionViewController.swift
//  HOSCO
//
//  Created by Adrian Mendoza Casado on 15/12/2018.
//  Copyright © 2018 AdriOS. All rights reserved.
//

import UIKit

class NoConnectionViewController: UIViewController {
    
    @IBOutlet weak var buttonConnect: UIButton!
    @IBOutlet weak var labelNoNetwork: UILabel!
    var presenter: NoConnectionPresenter!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.hidesBackButton = true
        labelNoNetwork.isHidden = true
        presenter = NoConnectionPresenter(view: self)
        
    }
    
    @IBAction func buttonConnectPressed(_ sender: UIButton) {
      presenter.handleReachability()
    }

}

extension NoConnectionViewController: NoConnectionProtocol {
    
    func dismissView() {
        self.dismiss(animated: true)
    }
    
    func showErrorConnectionLabel() {
        labelNoNetwork.isHidden = false
    }
}

