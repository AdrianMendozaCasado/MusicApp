//
//  ApiManagerProtocol.swift
//  HOSCO
//
//  Created by Adrian Mendoza Casado on 18/12/2018.
//  Copyright © 2018 AdriOS. All rights reserved.
//

import Foundation
import UIKit

protocol ApiManagerProtocol {
    
    func fetchSongs(textSearched: String,
                    onComplete: @escaping ([CellData]) -> Void,
                    onError: @escaping (Error) -> Void)
    
    func loadImage(urlString: String, image: UIImageView, placeholder: UIImage)
    
    func downloadSongPreview(urlString: String, onComplete: @escaping (Data) -> Void,
                             onError: @escaping (NSError) -> Void)
}
