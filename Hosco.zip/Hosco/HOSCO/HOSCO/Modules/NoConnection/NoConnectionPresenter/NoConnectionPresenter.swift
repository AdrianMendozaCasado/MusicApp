//
//  NoConnectionPresenter.swift
//  HOSCO
//
//  Created by Adrian Mendoza Casado on 07/01/2019.
//  Copyright © 2019 AdriOS. All rights reserved.
//

import Foundation

class NoConnectionPresenter {
    
    private var reachability = Reachability()
    private var view: NoConnectionProtocol
    
    
    init(view: NoConnectionProtocol) {
        self.view = view
    }
    
    func handleReachability() {
        if reachability.isInternetAvailable() {
            view.dismissView()
        }else{
            view.showErrorConnectionLabel()
        }
    }
}
