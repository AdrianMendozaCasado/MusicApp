//
//  ApiManager.swift
//  HOSCO
//
//  Created by Adrian Mendoza Casado on 16/12/2018.
//  Copyright © 2018 AdriOS. All rights reserved.
//

import Foundation
import Alamofire
import SDWebImage

class ApiManager: ApiManagerProtocol {
    
    
    func fetchSongs(textSearched: String, onComplete: @escaping ([CellData]) -> Void, onError: @escaping (Error) -> Void) {
        guard let url = URL(string: Constants.baseUrl + textSearched) else { return }
        
        Alamofire.request(url).responseJSON { response in
            if let json = response.data {
                do {
                    var tableViewData = [CellData]()
                    let results = try JSONDecoder().decode(Songs.self, from: json)
                    let songs = self.filterValues(results: results)
                    
                    if songs.count != 0 {
                        for song in songs {
                            let data = CellData(expandedCell: false, data: song)
                            tableViewData.append(data)
                        }
                       onComplete(tableViewData)
                    } else {
                        onError(NSError(domain: "Not found", code: 403, userInfo: nil))
                    }
                } catch {
                    onError(NSError(domain: "Error", code: 404, userInfo: nil))
                }
            }
        }
    }
    
    private func filterValues(results: Songs) -> [Results] {
        return results.results.filter({ (result) -> Bool in
            if result.kind == "song" {
                return true
            }
            return false
        })
    }
    
    func loadImage(urlString: String, image: UIImageView, placeholder: UIImage) {
        guard let url = URL(string: urlString) else { return }
        image.sd_setImage(with: url, placeholderImage: UIImage(named: "placeholder"))
    }
    
    func downloadSongPreview(urlString: String, onComplete: @escaping (Data) -> Void,
                             onError: @escaping (NSError) -> Void) {
        guard let url = URL(string: urlString) else { return }
        Alamofire.request(url).responseData { response in
            if let data = response.data {
                onComplete(data)
            }
            onError(NSError(domain: "Not found", code: 403, userInfo: nil))
        }
    }
}

