//
//  SearchForSongsSimpleCell.swift
//  HOSCO
//
//  Created by Adrian Mendoza Casado on 19/12/2018.
//  Copyright © 2018 AdriOS. All rights reserved.
//

import UIKit

class SearchForSongsSimpleCell: UITableViewCell {
    @IBOutlet weak var labelSongName: UILabel!
    @IBOutlet weak var labelArtistName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setUpSimpleCell(labelSongName: String, labelArtistName: String) {
        self.labelSongName.text = labelSongName
        self.labelArtistName.text = labelArtistName
    }
    
}
