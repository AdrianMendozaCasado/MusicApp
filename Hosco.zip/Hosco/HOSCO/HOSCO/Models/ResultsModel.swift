//
//  ResultsModel.swift
//  HOSCO
//
//  Created by Adrian Mendoza Casado on 16/12/2018.
//  Copyright © 2018 AdriOS. All rights reserved.
//

import Foundation

struct Songs: Decodable {
    var resultCount: Int?
    var results: [Results] = []
}

struct Results: Decodable {
    var artistName: String?
    var primaryGenreName: String?
    var trackName: String?
    var trackPrice: Double?
    var currency: String?
    var collectionName: String?
    var collectionPrice: Double?
    var releaseDate: String?
    var kind: String?
    var artworkUrl60: String?
    var artworkUrl100: String?
    var previewUrl: String?
    var trackTimeMillis: Int?
}

struct CellData {
    var expandedCell = false
    var data = Results()
}
