//
//  NoConnectionProtocol.swift
//  HOSCO
//
//  Created by Adrian Mendoza Casado on 07/01/2019.
//  Copyright © 2019 AdriOS. All rights reserved.
//

import Foundation

protocol NoConnectionProtocol: class {
    
    func dismissView()
    
    func showErrorConnectionLabel()
}
