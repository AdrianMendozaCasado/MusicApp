//
//  SongDetailProtocol.swift
//  HOSCO
//
//  Created by Adrian Mendoza Casado on 21/12/2018.
//  Copyright © 2018 AdriOS. All rights reserved.
//

import Foundation

protocol SongDetailViewProtocol: class {
    
    func showData(songs: [CellData], position: Int)
    
    func pauseButtonTitle()
    
    func playButtonTitle()
    
    func showActivityIndicator()
    
    func hideActivityIndicator()
    
    func navigateToNoConnectionVC()
    
    func showShareDialogue()
}
