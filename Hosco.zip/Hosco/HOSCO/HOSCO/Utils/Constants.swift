//
//  Constants.swift
//  HOSCO
//
//  Created by Adrian Mendoza Casado on 16/12/2018.
//  Copyright © 2018 AdriOS. All rights reserved.
//

import Foundation

struct Constants {
    static let baseUrl = "https://itunes.apple.com/search?term="
}
