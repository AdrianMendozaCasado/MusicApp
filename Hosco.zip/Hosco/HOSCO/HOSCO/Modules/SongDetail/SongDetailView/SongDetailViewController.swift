//
//  SongDetailViewController.swift
//  HOSCO
//
//  Created by Adrian Mendoza Casado on 21/12/2018.
//  Copyright © 2018 AdriOS. All rights reserved.
//

import UIKit
import SDWebImage

class SongDetailViewController: UIViewController {
    @IBOutlet weak var coverImage: UIImageView!
    @IBOutlet weak var songName: UILabel!
    @IBOutlet weak var artistName: UILabel!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var backButton: UIButton!
    
    private var activityViewController: UIActivityViewController!
    var presenter: SongDetailPresenter!
    private var currentSong: Data?
    private var shareButton =  UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        backButton.tag = 0
        nextButton.tag = 1
        playButton.tag = 2
        presenter.viewDidLoad()
        shareButton.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        shareButton.setImage(UIImage(named: "share"), for: .normal)
        shareButton.widthAnchor.constraint(equalToConstant: shareButton.frame.size.width).isActive = true
        shareButton.heightAnchor.constraint(equalToConstant: shareButton.frame.size.height).isActive = true
        shareButton.addTarget(self, action: #selector(addTapped), for: .touchUpInside)
        let rightNavigationItem = UIBarButtonItem(customView: shareButton)
        self.navigationItem.setRightBarButton(rightNavigationItem, animated: true)
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        presenter.didLeaveView()
    }

    @IBAction func playSong(_ sender: Any) {
        presenter.handleSongControls(tag: playButton.tag)
    }
    @IBAction func nextSong(_ sender: Any) {
        presenter.handleSongControls(tag: nextButton.tag)
    }
    
    @IBAction func previousSong(_ sender: Any) {
        presenter.handleSongControls(tag: backButton.tag)
    }
    
    @objc func addTapped() {
        activityViewController = UIActivityViewController(
            activityItems: ["I'm listening \(presenter.currentSong) song on hosco app!"],
            applicationActivities: nil)
        present(activityViewController, animated: true, completion: nil)
    }
}


extension SongDetailViewController: SongDetailViewProtocol {
    
    func showData(songs: [CellData], position: Int) {
        self.artistName.text = songs[position].data.artistName
        self.songName.text = songs[position].data.trackName
        coverImage.sd_setImage(with: URL(string: songs[position].data.artworkUrl100!), placeholderImage: UIImage(named: "placeholder"))
    }
    
    func pauseButtonTitle() {
        self.playButton.setTitle("Pause", for: .normal)
    }
    
    func playButtonTitle() {
        self.playButton.setTitle("Play", for: .normal)
    }
    
    func showActivityIndicator() {
        self.view.activityStartAnimating(activityColor: .white, backgroundColor: UIColor.black.withAlphaComponent(0.5))
    }
    
    func hideActivityIndicator() {
        self.view.activityStopAnimating()
    }
    
    func navigateToNoConnectionVC() {
        let noConnectionSB = UIStoryboard(name: "NoConnection", bundle: nil)
        let noConnectionVC = noConnectionSB.instantiateViewController(withIdentifier: "NoConnectionVC")
        self.present(noConnectionVC, animated: true)
    }
    
    func showShareDialogue() {
        self.addTapped()
    }
}
