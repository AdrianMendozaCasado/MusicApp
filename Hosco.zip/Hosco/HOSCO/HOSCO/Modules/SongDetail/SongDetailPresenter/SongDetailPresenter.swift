//
//  SongDetailPresenter.swift
//  HOSCO
//
//  Created by Adrian Mendoza Casado on 21/12/2018.
//  Copyright © 2018 AdriOS. All rights reserved.
//

import Foundation
import AVFoundation

class SongDetailPresenter {
    
    private var view: SongDetailViewProtocol
    private var apiManager: ApiManagerProtocol
    var songsList = [CellData]()
    var currentPosition: Int?
    private var player: AVAudioPlayer?
    private var songAudio: Data?
    private var isPlaying = false
    private var reachability = Reachability()
    
    
    init(view: SongDetailViewProtocol) {
        self.view = view
        self.apiManager = ApiManager()
    }
    
    func viewDidLoad() {
        if !reachability.isInternetAvailable() {
            view.navigateToNoConnectionVC()
        }else{
            guard let position = currentPosition else { return }
            view.showData(songs: songsList, position: position)
            self.downloadSong(position: position)
        }
    }
    
    private func downloadSong(position: Int) {
        view.showActivityIndicator()
        isPlaying = false
        guard let url = songsList[position].data.previewUrl else { return }
        apiManager.downloadSongPreview(urlString: url, onComplete: { [weak self] (data) in
            guard let strongSelf = self else { return }
            strongSelf.songAudio = data
            strongSelf.initAudioPlayer(data: data, onComplete: {
                strongSelf.view.hideActivityIndicator()
            })
        }) { (error) in
            print(error.localizedDescription)
        }
    }
    
    private func initAudioPlayer(data: Data?, onComplete: @escaping () -> Void) {
        guard let song = data else { return }
        do {
            player = try AVAudioPlayer(data: song)
            onComplete()
        }
        catch {
            print("Error getting the audio file")
        }
    }
    
    func didLeaveView() {
        guard let avPlayer = player else { return }
        if isPlaying{
            avPlayer.pause()
        }
    }
    
    func handleSongControls(tag: Int) {
        if !reachability.isInternetAvailable() {
            view.navigateToNoConnectionVC()
        }else{
            var newPosition = Int()
            guard let position = currentPosition else { return }
            view.playButtonTitle()
            switch tag {
            case 0:
                newPosition = position - 1
                if newPosition >= 0 {
                    view.showData(songs: songsList, position: newPosition)
                    downloadSong(position: newPosition)
                    currentPosition = newPosition
                }else{
                    currentPosition = songsList.count - 1
                    guard let lastPosition = currentPosition else { return }
                    view.showData(songs: songsList, position: lastPosition)
                    downloadSong(position: lastPosition)
                    currentPosition = lastPosition
                }
            case 1:
                newPosition = position + 1
                if newPosition < songsList.count {
                    view.showData(songs: songsList, position: newPosition)
                    downloadSong(position: newPosition)
                    currentPosition = newPosition
                }else{
                    currentPosition = 0
                    guard let firstPosition = currentPosition else { return }
                    view.showData(songs: songsList, position: firstPosition)
                    downloadSong(position: firstPosition)
                    currentPosition = firstPosition
                }
            case 2:
                guard let avPlayer = player else { return }
                if isPlaying {
                    avPlayer.pause()
                    view.playButtonTitle()
                    isPlaying = false
                }else{
                    avPlayer.play()
                    view.pauseButtonTitle()
                    isPlaying = true
                }
            default:
                break
                
            }
        }
    }
    
    func showShareDialogue() {
        view.showShareDialogue()
    }
    
    var currentSong: String {
        guard let position = currentPosition else { return "a" }
        guard let songName = songsList[position].data.trackName else { return "a"}
    return songName
    }
}
