//
//  FormatterManager.swift
//  HOSCO
//
//  Created by Adrian Mendoza Casado on 19/12/2018.
//  Copyright © 2018 AdriOS. All rights reserved.
//

import Foundation

protocol NumberFormatterProtocol {
    func convertDoubleToString(numberToConvert: Double?) -> String?
}


class FormatterManager {
    
    func convertDoubleToString(numberToConvert: Double?) -> String {
        var value = String()
        if let doubleToString = numberToConvert {
             value = String(format: "%0.2f", doubleToString)
        }
        return value
    }
    
    func convertDateToString(text: String?) -> String {
        var value = String()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        guard let noNilText = text else { return "Unknown Date" }
        if let date = dateFormatter.date(from:noNilText) {
            dateFormatter.dateFormat = "yyyy/MM/dd"
            value = dateFormatter.string(from: date)
        }
        return value
    }
}


