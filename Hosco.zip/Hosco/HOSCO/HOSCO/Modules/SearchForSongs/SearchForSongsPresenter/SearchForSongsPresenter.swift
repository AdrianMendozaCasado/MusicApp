//
//  SearchForSongsPresenter.swift
//  HOSCO
//
//  Created by Adrian Mendoza Casado on 15/12/2018.
//  Copyright © 2018 AdriOS. All rights reserved.
//

import Foundation
import SDWebImage

class SearchForSongsPresenter {
    
    private var view: SearchForSongsViewProtocols
    private var apiManager: ApiManagerProtocol
    var textSearched: String?
    private var resultsArray: [CellData] = []
    private var detailPresenter: SongDetailPresenter?
    private var reachability = Reachability()
    
    init(view: SearchForSongsViewProtocols) {
        self.view = view
        self.apiManager = ApiManager()
    }
    
    func searchSong() {
        if !reachability.isInternetAvailable() {
            view.navigateToNoConnectionVC()
        }else{
            view.showActivityIndicator()
            guard let searchText = textSearched else { return }
            apiManager.fetchSongs(textSearched: searchText, onComplete: { [weak self](results) in
                guard let strongSelf = self else { return }
                strongSelf.resultsArray = results
                strongSelf.view.showData(songs: results)
                strongSelf.view.refresh()
                strongSelf.view.hideActivityIndicator()
                strongSelf.view.dismissKeyboardWhenSearchFinish()
            }) { (error) in
                print(error.localizedDescription)
                self.view.hideData()
            }
        }
    }
    
    func didSelectedRow(index: IndexPath, data: [CellData]) {
        if data[index.section].expandedCell {
            view.expandCell(index: index)
        } else {
            view.collapseCell(index: index)
        }
    }
    
    func listenTapped(currentPosition: Int) {
        view.navigateToDetailVC(songs: resultsArray, position: currentPosition)
    }

    func showFilterAlert() {
        view.showFilterAlert()
    }
    
}
