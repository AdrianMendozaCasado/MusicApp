//
//  SearchForSongsViewController.swift
//  HOSCO
//
//  Created by Adrian Mendoza Casado on 15/12/2018.
//  Copyright © 2018 AdriOS. All rights reserved.
//

import UIKit
import SDWebImage
import SCLAlertView

enum State {
    case initialView
    case noDataFound
    case showTableView
}

class SearchForSongsViewController: UIViewController {
    
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var labelState: UILabel!
    @IBOutlet weak var filterButton: UIButton!
    var presenter: SearchForSongsPresenter!
    var songsList = [CellData]()
    var formatterManager: FormatterManager!
    var image: UIImage?
    var reachability = Reachability()
    
    var state: State = .initialView {
        didSet {
            switch state {
            case .initialView:
                self.tableView.isHidden = true
                self.labelState.text = ""
                self.filterButton.isEnabled = false
            case .noDataFound:
                self.tableView.isHidden = true
                self.labelState.text = "No results found"
                self.tableView.reloadData()
                self.hideActivityIndicator()
                self.filterButton.isEnabled = false
            case .showTableView:
                self.tableView.isHidden = false
                tableView.separatorStyle = .none
                self.labelState.text = ""
                self.tableView.reloadData()
                self.filterButton.isEnabled = true
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter = SearchForSongsPresenter(view: self)
        self.formatterManager = FormatterManager()
        self.state = .initialView
        tableView.register(UINib(nibName: "SearchforSongsExpandedCell", bundle: nil), forCellReuseIdentifier: "ExpandedCell")
        tableView.register(UINib(nibName: "SearchForSongsSimpleCell", bundle: nil), forCellReuseIdentifier: "SimpleCell")
        tableView.estimatedRowHeight = 200
        self.hideKeyboardWhenTappedAround()
    }
    
    @IBAction func filterPressed(_ sender: Any) {
        self.showFilterAlert()
    }
    
    
    private func buttonExpandCellPressed() {
        self.tableView.reloadData()
    }
    
    //MARK -Navigation Methods
    private func navigateToDetailView(data: [CellData], currentPosition: Int) {
        presenter.listenTapped(currentPosition: currentPosition)
    }
}

//MARK - TableView Methods
extension SearchForSongsViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if songsList.count > 0 {
            if songsList[section].expandedCell {
                return 2
            } else {
                return 1
            }
        }else{
            return 0
        }
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if songsList.count != 0 {
            return songsList.count
        }
        return 0
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == 0 {
            let simpleCell = tableView.dequeueReusableCell(withIdentifier: "SimpleCell", for: indexPath) as! SearchForSongsSimpleCell
            simpleCell.setUpSimpleCell(labelSongName: songsList[indexPath.section].data.trackName ?? "Unknown song name" ,labelArtistName: songsList[indexPath.section].data.artistName ?? "Unknown artist name")
            return simpleCell
            
        } else {
            let expandedCell = tableView.dequeueReusableCell(withIdentifier: "ExpandedCell", for: indexPath) as! SearchforSongsExpandedCell
            expandedCell.buttonListen.tag = indexPath.section
            let priceToString = formatterManager.convertDoubleToString(numberToConvert: songsList[indexPath.section].data.trackPrice ?? 0)
            let finalPrice = priceToString.appending(songsList[indexPath.section].data.currency ?? "USD")
            let finalDate = formatterManager.convertDateToString(text: songsList[indexPath.section].data.releaseDate ?? "Unknown date")
            expandedCell.thumbnail.sd_setImage(with: URL(string: songsList[indexPath.section].data.artworkUrl60!), placeholderImage: UIImage(named: "placeholder"))
            self.image = expandedCell.thumbnail.image
            let miliSeconds = songsList[indexPath.section].data.trackTimeMillis ?? 0
            let duration = miliSeconds.msToSeconds.minuteSeconds
           
            expandedCell.setup(
                labelAlbumtitle: songsList[indexPath.section].data.collectionName ?? "Unknown album name",
                labelReleaseDate: finalDate,
                labelDuration: duration,
                labelGenre: songsList[indexPath.section].data.primaryGenreName ?? "Unknown genre",
                labelPrice: finalPrice)
            expandedCell.buttonListen.addTarget(self, action: #selector(cellButtonCicked(sender:)), for: .touchUpInside)
            
            return expandedCell
            
        }
    }
    
    @objc func cellButtonCicked(sender: UIButton) {
        navigateToDetailVC(songs: songsList, position: sender.tag)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

extension SearchForSongsViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        presenter.didSelectedRow(index: indexPath, data: songsList)
    }
}

//MARK - Protocols
extension SearchForSongsViewController: SearchForSongsViewProtocols {
    
    func expandCell(index: IndexPath) {
        songsList[index.section].expandedCell = false
        let section = IndexSet.init(integer: index.section)
        tableView.reloadSections(section, with: .left)
    }
    
    func collapseCell(index: IndexPath) {
        songsList[index.section].expandedCell = true
        let section = IndexSet.init(integer: index.section)
        tableView.reloadSections(section, with: .right)
    }
    
    func showData(songs: [CellData]) {
        state = .showTableView
        songsList = songs
    }
    
    func hideData() {
        state = .noDataFound
    }
    
    func refresh() {
        self.tableView.reloadData()
    }
    
    func navigateToDetailVC(songs: [CellData], position: Int) {
        let detailSB = UIStoryboard(name: "SongDetail", bundle: nil)
        let detailVC = detailSB.instantiateViewController(withIdentifier: "SongDetailView") as! SongDetailViewController
        detailVC.presenter = SongDetailPresenter(view: detailVC)
        detailVC.presenter.currentPosition = position
        detailVC.presenter.songsList = songs
        navigationController?.pushViewController(detailVC, animated: true)
    }
    
    func navigateToNoConnectionVC() {
        let noConnectionSB = UIStoryboard(name: "NoConnection", bundle: nil)
        let noConnectionVC = noConnectionSB.instantiateViewController(withIdentifier: "NoConnectionVC")
        self.present(noConnectionVC, animated: true)
    }
    
    func showActivityIndicator() {
        self.view.activityStartAnimating(activityColor: .white, backgroundColor: UIColor.black.withAlphaComponent(0.5))
    }
    
    func hideActivityIndicator() {
        self.view.activityStopAnimating()
    }
    
    func dismissKeyboardWhenSearchFinish() {
        self.searchBar.resignFirstResponder()
        self.dismissKeyboard()
    }
    
    func showFilterAlert() {
        let appearance = SCLAlertView.SCLAppearance(
            kTitleFont: UIFont(name: "AvenirNext-Bold", size: 20)!,
            kButtonFont: UIFont(name: "AvenirNext-Bold", size: 14)!,
            showCloseButton: true
        )
        let alert = SCLAlertView(appearance: appearance)
        let alertViewIcon = UIImage(named: "filter")
        let tintedAlertIcon = alertViewIcon?.tint(with: .white)
        alert.addButton("Price") {
            self.songsList.sort { (item1, item2) -> Bool in
                let value1 = item1.data.trackPrice ?? 0
                let value2 = item2.data.trackPrice ?? 0
                return value1 < value2
            }
            self.tableView.reloadData()
        }
        
        alert.addButton("Song Length") {
            self.songsList.sort { (item1, item2) -> Bool in
                let value1 = item1.data.trackTimeMillis ?? Int.max
                let value2 = item2.data.trackTimeMillis ?? Int.max
                return value1 < value2
            }
            self.tableView.reloadData()
        }
        
        alert.addButton("Genre") {
            self.songsList.sort {(item1, item2) -> Bool in
                let value1 = item1.data.primaryGenreName ?? "Unknown Genre"
                let value2 = item2.data.primaryGenreName ?? "Unknown Genre"
                return value1 < value2
            }
            self.tableView.reloadData()
        }
        
        alert.showInfo("Filter by:", subTitle: "", closeButtonTitle: "Cancel", circleIconImage: tintedAlertIcon)
    }
    

}


extension SearchForSongsViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        let finalSeatchText = searchText.replacingOccurrences(of: " ", with: "+")
        presenter.textSearched = finalSeatchText
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        presenter.searchSong()
    }
    
}

