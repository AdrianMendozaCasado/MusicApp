//
//  SearchforSongsExpandedCell.swift
//  HOSCO
//
//  Created by Adrian Mendoza Casado on 19/12/2018.
//  Copyright © 2018 AdriOS. All rights reserved.
//

import UIKit

class SearchforSongsExpandedCell: UITableViewCell {

    @IBOutlet weak var labelAlbumtitle: UILabel!
    @IBOutlet weak var labelReleaseDate: UILabel!
    @IBOutlet weak var labelDuration: UILabel!
    @IBOutlet weak var labelGenre: UILabel!
    @IBOutlet weak var labelPrice: UILabel!
    @IBOutlet weak var buttonListen: UIButton!
    @IBOutlet weak var thumbnail: UIImageView!
    var numberFormatter: NumberFormatterProtocol!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setup(labelAlbumtitle: String, labelReleaseDate: String, labelDuration: String,
               labelGenre: String, labelPrice: String) {
        self.labelAlbumtitle.text = "Album: " + labelAlbumtitle
        self.labelReleaseDate.text = "Release Date: " + labelReleaseDate
        self.labelDuration.text = "Duration: " + labelDuration
        self.labelGenre.text = "Genre: " + labelGenre
        self.labelPrice.text = "Price: " + labelPrice
    }
    
}

