//
//  SearchForSongsViewProtocols.swift
//  HOSCO
//
//  Created by Adrian Mendoza Casado on 18/12/2018.
//  Copyright © 2018 AdriOS. All rights reserved.
//

import Foundation

protocol SearchForSongsViewProtocols: class {
    
    func expandCell(index: IndexPath)
    
    func collapseCell(index: IndexPath)
    
    func showData(songs: [CellData])
    
    func hideData()
    
    func refresh()
    
    func navigateToDetailVC(songs: [CellData], position: Int)
    
    func showActivityIndicator()
    
    func hideActivityIndicator()
    
    func dismissKeyboardWhenSearchFinish()
    
    func navigateToNoConnectionVC()
    
    func showFilterAlert()
}

